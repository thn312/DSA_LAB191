#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <iomanip>
#include <math.h>
#include <cctype>

using namespace std;

/* Your code MUST NOT contain any words in the following list:
{"include", "while", "for", "goto"} even in the comments */

//----------------------------------------------
// Begin implementation
//----------------------------------------------



class Node {
public:
	int data;
	Node* left;
	Node* right;

	Node(int val) {
		data = val;
		left = right = NULL;
	}
};

class BinaryTree
{
private:
	Node * root;
	int size;
protected:
	void clearRecursion(Node*root);
    void addBSTRecursion(Node*& root, int val);
    int deleteBSTRecursion(Node*& root, int val);
    int countTwoChildrenNodesRecursion(Node* root);

public:
	BinaryTree();
	~BinaryTree();
	void clear();
	void addBST(int val);
    int deleteBST(int val);
	void printTreeStructure();
	int countTwoChildrenNodes();
};

int main(int argc, char** argv) {


	ifstream ifs;
	ifs.open("Text.txt", ifstream::in);

	string temp;
	getline(ifs, temp);

	int n = stoi(temp);
	int* arr = new int[n];

	for (int i = 0; i < n; i++) {
		getline(ifs, temp);
		arr[i] = stoi(temp);
	}

	BinaryTree* tree = new BinaryTree();
	for (int i = 0; i < n; i++) {
		tree->addBST(arr[i]);
	}

	cout << tree->countTwoChildrenNodes() << endl;

	ifs.close();
	system("pause");
	return 0;
}

BinaryTree::BinaryTree()
{
	root = NULL;
	size = 0;
}

BinaryTree::~BinaryTree()
{
	clear();
}

void BinaryTree::clearRecursion(Node* root) {
	if (root != NULL) {
		clearRecursion(root->left);
		clearRecursion(root->right);
		delete root;
	}
}
void BinaryTree::clear() {
	clearRecursion(root);
}

void BinaryTree::addBSTRecursion(Node*& root, int val) {
	if (root == NULL) 
		root = new Node(val);
	else {
		if (val > root->data)
			addBSTRecursion(root->right, val);
		else
			addBSTRecursion(root->left, val);
	}
}

void BinaryTree::addBST(int val) {
	addBSTRecursion(root, val);
}

int BinaryTree::deleteBSTRecursion(Node*& root, int val) {
	if (root == NULL)
		return false;
	else if (root->data > val)
		return deleteBSTRecursion(root->left, val);
	else if (root->data < val)
		return deleteBSTRecursion(root->right, val);
	else {
		if (root->left == NULL) {
			Node* p = root;
			root = root->right;
			delete p;
			return true;
		}
		else if (root->right == NULL) {
			Node* p = root;
			root = root->left;
			delete p;
			return true;
		}
		else {
			Node* p = root->left;
			while (p->right) p = p->right;
			root->data = p->data;
			return deleteBSTRecursion(root->left, p->data);
		}
	}
}

int BinaryTree::deleteBST(int val) {
	return deleteBSTRecursion(root, val);
}



int BinaryTree::countTwoChildrenNodesRecursion(Node* root) {
	// TODO
	if (root != NULL) {
		int a = countTwoChildrenNodesRecursion(root->left);
		int b = countTwoChildrenNodesRecursion(root->right);
		if (root->left != NULL && root->right != NULL) {
			return 1 + a + b;
		}
		return a + b;
	}
	
	return 0;
}

int BinaryTree::countTwoChildrenNodes() {
	return countTwoChildrenNodesRecursion(root);
}
